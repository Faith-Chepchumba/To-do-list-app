# To-Do List App

## Overview

A simple To-Do List app that allows users to add and view tasks.

## Features

- Add tasks to the list
- Simple and intuitive interface

## Technologies Used

- HTML
- CSS
- JavaScript

## How to Run

1. Open index.html in a web browser.

2. Add tasks using the input field.